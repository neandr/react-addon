var DeleteModal = props => React.createElement(
  ReactModal,
  {
    isOpen: true,
    contentLabel: "Modal",
    className: "modal"
  },
  React.createElement(
    "h3",
    null,
    "Are you sure you want to delete ",
    React.createElement(
      "b",
      null,
      props.name
    ),
    "?"
  ),
  React.createElement(
    "div",
    null,
    React.createElement(
      "button",
      { className: "buttons", onClick: props.confirmDelete },
      "Yes"
    ),
    React.createElement(
      "button",
      { className: "buttons", onClick: props.noDelete },
      "No"
    )
  )
);
