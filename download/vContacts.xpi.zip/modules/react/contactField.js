/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/** -------------- CONTACT FIELDS -------------------------*/

var ContactField = React.createClass({
    displayName: "ContactField",

    saveContent: function (event) {
        this.props.onUserInput(event.target.value, this.props.index);
    },
    saveOption: function (event) {
        this.props.onUserSelect(event.target.value, this.props.index);
    },
    remove: function () {
        this.props.onUserDelete(this.props.index);
    },
    renderOption: function (option) {
        return React.createElement(
            "option",
            { value: option },
            option
        );
    },
    renderDisplay: function () {
        if (this.props.type == "Address") {
            return React.createElement(AddressField, {
                fieldContent: this.props.fieldContent,
                currentOption: this.props.currentOption
            });
        }
        return React.createElement(
            "div",
            { id: "field" },
            React.createElement(
                "p",
                null,
                this.props.currentOption,
                ": ",
                this.props.fieldContent
            )
        );
    }, renderForm: function () {
        if (this.props.type == "Address") {
            return React.createElement(AddressForm, {
                currentOption: this.props.currentOption,
                saveOption: this.props.onUserSelect,
                renderOption: this.renderOption,
                options: this.props.options,
                remove: this.remove,
                saveContent: this.props.onUserInput,
                fieldContent: this.props.fieldContent,
                index: this.props.index
            });
        }
        return React.createElement(
            "table",
            { id: "field" },
            React.createElement(
                "tr",
                null,
                React.createElement(
                    "td",
                    null,
                    React.createElement(
                        "select",
                        { onChange: this.saveOption, value: this.props.currentOption },
                        this.props.options.map(this.renderOption)
                    )
                ),
                React.createElement(
                    "td",
                    null,
                    React.createElement("input", { type: "text", ref: "newText", defaultValue: this.props.fieldContent, className: "form-control", onChange: this.saveContent })
                ),
                React.createElement(
                    "td",
                    null,
                    React.createElement(
                        "button",
                        { className: "buttons remove", onClick: this.remove },
                        "-"
                    )
                )
            )
        );
    }, render: function () {
        if (this.props.editing) {
            return this.renderForm();
        } else {
            return this.renderDisplay();
        }
    }
});
