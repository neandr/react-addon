/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/**
* @desc Provides a header to the contact sidebar. It allows importing and exporting
* of contacts as well as creating new ones. It also provides a search bar for filtering contacts
**/
var SidebarHeader = props => React.createElement(
  "div",
  { id: "sidebar-header" },
  React.createElement(
    "div",
    null,
    React.createElement("input", { id: "search-bar", type: "text", name: "search", placeholder: "Search" })
  ),
  React.createElement(
    "span",
    { id: "sidebar-buttons" },
    React.createElement(
      "button",
      { className: "buttons", onClick: props.export },
      "Export"
    ),
    React.createElement(
      "button",
      { className: "buttons", onClick: props.import },
      "Import"
    ),
    React.createElement(
      "button",
      { className: "buttons", onClick: props.add },
      "+"
    )
  )
);
