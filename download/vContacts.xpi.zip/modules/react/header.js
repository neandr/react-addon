/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

var Header = React.createClass({
  displayName: "Header",

  saveContent(detail) {
    this.props.onUserInput(detail, this.refs[detail].value);
  },
  saveImage() {
    this.props.onNewImage(this.imageFile);
  },
  clickedImage() {
    //clicks the input file upload button.
    this.imageFile.click();
  },
  renderDisplay() {
    return React.createElement(
      "div",
      { id: "header" },
      React.createElement(ProfileImage, { type: "header", id: "profile-img", className: "profile-img", image: this.props.image }),
      React.createElement(
        "div",
        { id: "header-text" },
        React.createElement(
          "h3",
          null,
          this.props.personalDetails.name.content
        ),
        React.createElement(
          "h4",
          null,
          this.props.personalDetails.nickName.content
        ),
        React.createElement(
          "h4",
          null,
          this.props.personalDetails.displayName.content
        ),
        React.createElement(
          "h5",
          null,
          this.props.personalDetails.birthday.content
        ),
        React.createElement(
          "description",
          { className: "headerstyle" },
          "Tags"
        ),
        React.createElement(
          "button",
          { className: "buttons tag" },
          "Private"
        ),
        React.createElement(
          "button",
          { className: "buttons tag" },
          "Friends"
        )
      )
    );
  },
  renderForm() {
    var click = this.clickedImage.bind(this);
    return React.createElement(
      "div",
      { id: "header" },
      React.createElement(
        "div",
        { id: "profile-img" },
        React.createElement(ProfileImage, { imageClick: click, type: "header", id: "profile-img", className: "profile-img editing", image: this.props.image }),
        React.createElement("input", { className: "buttons upload", type: "file", ref: ref => this.imageFile = ref, name: "profile-picture", accept: "image/*", onChange: evt => this.saveImage(evt) })
      ),
      React.createElement(
        "div",
        { id: "header-text" },
        React.createElement(
          "table",
          { id: "header-field" },
          React.createElement(
            "tr",
            null,
            React.createElement(
              "td",
              null,
              React.createElement("input", { type: "text", ref: "name", defaultValue: this.props.personalDetails.name.content, placeholder: "Name", className: "form-control", onChange: this.saveContent.bind(null, "name") })
            )
          ),
          React.createElement(
            "tr",
            null,
            React.createElement(
              "td",
              null,
              React.createElement("input", { type: "text", ref: "nickName", defaultValue: this.props.personalDetails.nickName.content, placeholder: "Nickname", className: "form-control", onChange: this.saveContent.bind(null, "nickName") })
            )
          ),
          React.createElement(
            "tr",
            null,
            React.createElement(
              "td",
              null,
              React.createElement("input", { type: "text", ref: "displayName", defaultValue: this.props.personalDetails.displayName.content, placeholder: "Display name", className: "form-control", onChange: this.saveContent.bind(null, "displayName") })
            )
          ),
          React.createElement(
            "tr",
            null,
            React.createElement(
              "td",
              null,
              React.createElement("input", { type: "text", ref: "birthday", defaultValue: this.props.personalDetails.birthday.content, placeholder: "Birthday", className: "form-control", onChange: this.saveContent.bind(null, "birthday") })
            )
          ),
          React.createElement(
            "tr",
            null,
            React.createElement(
              "td",
              null,
              React.createElement(
                "description",
                { className: "headerstyle" },
                "Tag"
              ),
              React.createElement(
                "button",
                { className: "buttons tag", onClick: this.save },
                "Private"
              ),
              React.createElement(
                "button",
                { className: "buttons remove" },
                "-"
              ),
              React.createElement(
                "button",
                { className: "buttons tag", onClick: this.save },
                "Friends"
              ),
              React.createElement(
                "button",
                { className: "buttons remove" },
                "-"
              ),
              React.createElement(
                "button",
                { className: "buttons add" },
                " + "
              )
            )
          )
        )
      )
    );
  },
  render() {
    if (this.props.editing) {
      return this.renderForm();
    }
    return this.renderDisplay();
  }
});

ReactDOM.render(React.createElement(Header, null), document.getElementById('header-text'));
